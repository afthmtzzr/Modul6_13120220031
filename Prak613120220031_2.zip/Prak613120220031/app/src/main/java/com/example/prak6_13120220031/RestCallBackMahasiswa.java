package com.example.prak6_13120220031;

import java.util.ArrayList;

public interface RestCallBackMahasiswa {
    void requestDataMhsSuccess(ArrayList<Mahasiswa> arrayList);
}
